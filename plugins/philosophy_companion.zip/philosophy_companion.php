<?php
/*
Plugin Name: Philosophy Companion
Plugin Url: 
Description: Philosophy custom plugin
Version: 1.0
Author: Hasan Mahmud
Author URI:
License: GPLv2 or later
Text Domain: philosophy_companion
*/


function philosophy_companion_register_my_cpts_book() {

/**
 * Post Type: Books.
 */

$labels = [
    "name" => __( "Books", "philosophy" ),
    "singular_name" => __( "book", "philosophy" ),
    "featured_image" => __( "Book cover image", "philosophy" ),
];

$args = [
    "label" => __( "Books", "philosophy" ),
    "labels" => $labels,
    "description" => "",
    "public" => true,
    "publicly_queryable" => true,
    "show_ui" => true,
    "show_in_rest" => true,
    "rest_base" => "",
    "rest_controller_class" => "WP_REST_Posts_Controller",
    "rest_namespace" => "wp/v2",
    "has_archive" => "books",
    "show_in_menu" => true,
    "show_in_nav_menus" => true,
    "delete_with_user" => false,
    "exclude_from_search" => false,
    "capability_type" => "post",
    "map_meta_cap" => true,
    "hierarchical" => false,
    "can_export" => false,
    "rewrite" => [ "slug" => "book", "with_front" => false ],
    "query_var" => true,
    "menu_icon" => "dashicons-admin-settings",
    "supports" => [ "title", "editor", "thumbnail", "excerpt" ],
    "taxonomies" => [ "category" ],
    "show_in_graphql" => false,
];

register_post_type( "book", $args );
}

add_action( 'init', 'philosophy_companion_register_my_cpts_book' );
